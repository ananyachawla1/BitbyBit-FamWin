# Flutter Forum Application

Created using Flutter, I am learning about this amazing framework and creating UI for generic Forum application


# Login Screen
<img src="flutter_02.png" width="200"/>

# Home Screen
<img src="flutter_01.png" width="200"/>

# Forum Screen
<img src="flutter_03.png" width="200"/>

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
